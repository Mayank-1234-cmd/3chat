<!--<script>prompt("press F to pay respects (chat program broken :/)","F")</script>
uncomment when broken-->
<!--
todo:
  learn regex add bbcode iframe
  make recaptcha work
dont expect these to be added
helo
files that DO STUFF:
index.php (this page)
create.php (create chat)
post.php (post a message)
roomlist.php (list of rooms)
read.php (reads chats)-->
<body>

<!-- <script src="https://www.google.com/recaptcha/api.js"></script>
  <script>
   function onSubmit(token) {
     document.getElementById("demo-form").submit();
   }
 </script> -->
<?php
$bannedIP=array();
$permbans=array();
$r=htmlspecialchars($r);
if (!isset($_GET['room'])) {
  header("Location: /?room=default");
}
?>

<sub><i><a href="/cli/chat.py">download cli version</a> <a href="javascript:(function()%7Bconst%20addCSS%20%3D%20s%20%3D%3E(d%3D%3E%7Bd.head.appendChild(d.createElement(%22style%22)).innerHTML%3Ds%7D)(document)%3BaddCSS(%22*%2Cinput%2Ctextarea%7Bbackground-color%3A%23383838%3Bcolor%3Awhite%3B%7D%22)%7D)()">dark mode</a></sub></i>
<noscript><h1>Since JS isn't enabled, the chat can't auto-update, because it requires a iframe that keeps refreshing itself which shows the content of the file. Dark mode doesn't to because it needs js.<br/>Please enable JS to get the best experience.</h1></noscript>

<?php
foreach  ($bannedIP as &$onebannedip) {
  if (hash('sha512',substr($_SERVER["HTTP_X_FORWARDED_FOR"], 0, 24)) == $onebannedip) {
    die("<h1>Sorry, tempbanned.</h1>");
  }
}
foreach ($permbans as &$permban) {
  if (hash('sha512',substr($_SERVER["HTTP_X_FORWARDED_FOR"], 0, 12)) == $onebannedip) {
    die("<h1>Sorry, it seems like this region is banned because someone abused the chat. If you think this is a mistake, contact mayank.charlotte@gmail.com.</h1>");
  }
}
if (isset($_SERVER['SCRIPT_NAME'])) {
  file_put_contents(".logs","[".date("Y.m.d h:i.s")."] ".hash('sha512',substr($_SERVER["HTTP_X_FORWARDED_FOR"], 0, 24))." - ".$_SERVER['REQUEST_METHOD']." ".$_SERVER['SCRIPT_NAME']." (permban hash ".hash('sha512',substr($_SERVER["HTTP_X_FORWARDED_FOR"], 0, 12)).")\n".file_get_contents(".logs"));
} else {
  file_put_contents(".logs","[".date("Y.m.d h:i.s")."] ".hash('sha512',substr($_SERVER["HTTP_X_FORWARDED_FOR"], 0, 24))." - ".$_SERVER['REQUEST_METHOD']." undefined - permban ".hash('sha512',substr($_SERVER["HTTP_X_FORWARDED_FOR"], 0, 12))."\n".file_get_contents(".logs"));
}
if (isset($r)) {
  ; // do nothing
}
else {
  //echo "<script>alert('Note: Go fullscreen, otherwise you may experience a minor seizure, because the refresh button changes from x to [refresh icon] and vice versa, and i cant do anything about it without removing the auto update feature.')</script>";
  header("Location: /?room=default");
}
?>
<!-- bootstrap -->
</style>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>
<sticky><iframe id="rooms" style="width:100%;" src="/roomlist.php"></iframe></sticky>
<iframe id="myframe" src=<?php echo '"/read.php?room='.$r.'"';?> style="width:100%;height:65%;"> </iframe>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>
// window.setInterval("reloadIFrame();", );
<?php $r=$_GET['room'];?>
function reloadIFrame() {
  // document.getElementById("myframe").src="/read.php?room=<?php echo $r;?>";
  // val=fetch("/read.php?room=<?php echo $r;?>").then(res => { document.getElementById("test").value=res;alert(res); });
  //start stackovefrlow
  const proxyurl = "";
  const url = "/read.php?room=<?php echo $r;?>"; // site that doesn’t send Access-Control-*
  fetch(proxyurl + url) // https://cors-anywhere.herokuapp.com/https://example.com
    .then(response => response.text())  
  .then(html => {
    // console.log(html);
    // document.getElementById('test').innerHTML = html;
    document.getElementById( 'myframe' ).setAttribute( 'src', url );
    // document.getElementById('test').innerHTML=html;
    // alert()
  })
  .catch((err) => console.log("Can’t access " + url + " response. Blocked by browser?" + err));
}
reloadIFrame()
//  window.setInterval("reloadIFrame();", 2000);
</script><!--
<button class="input-group-text btn btn-important" onclick="reloadIFrame()" style="font-size:10px;">reload chat</button>
<button class="input-group-text btn btn-important" onclick="autoReloadFrame()" style="font-size:10px;">auto-reload chat</button>
-->
<button type="button" onclick='window.setInterval("reloadIFrame();", 2000);'>Auto-reload chat (fixes bugs)</button> <button type="button" onclick='reloadIFrame();'>Reload chat</button>

<br/>
<div class="input-group">
<!--<input type="text" placeholder="avatar link.." id="avt" class="form-control">-->
  <input type="text" placeholder="name.." id="usef" class="form-control" value=<?php echo '"'.$_GET['user'].'"';?>>
  <input type="text" placeholder="comment.." id="comment" class="form-control">
<button class="input-group-text btn btn-important g-recaptcha" id="cofmment"  onclick=<?php echo '"'."fetch('/post.php?user=' + document.getElementById('usef').value + '&comment=' + document.getElementById('comment').value + '&room=" . $r."'".')"';?>>comment</button>
</div><!--<img src="https://community-whjr.imgix.net/Community_v1_avatars/User+05b.png" style="width:30px;height:30px;"/>-->
<div class="input-group">
  <input type="roomcreatebtn" placeholder="room to create.." id="roomcreatebtn" class="form-control" >
  <button class="input-group-text btn btn-important" onclick="window.location='/index.php?room=' + document.getElementById('roomcreatebtn').value">join room</button>
  <button class="input-group-text btn btn-important"  onclick="window.location='/create.php?room='+ document.getElementById('roomcreatebtn').value">create room</button>
</div>

<link rel="stylesheet" href="/style.css">

<div id="test"></div>
<script>
var input = document.getElementById("comment");

// Execute a function when the user releases a key on the keyboard
input.addEventListener("keyup", function(event) {
  // Number 13 is the "Enter" key on the keyboard
  if (event.keyCode === 13) {
    // Cancel the default action, if needed
    event.preventDefault();
    // Trigger the button element with a click
    document.getElementById("cofmment").click();
  }
});
</script>
<style>
* {
  opacity: 75%;
}
body { 
  background-image: url('https://malwarewatch.org/images/backgrounds/background<?php echo rand(1,20);?>.jpg');
}
</style>