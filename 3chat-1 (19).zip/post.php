Uh oh! You have either spammed or are using a browser that isn't supported.<br/>Otherwise your computer may be low on ram.
<?php

// 
require_once "jbbcode/jBBCode/JBBCode/Parser.php";





$adminpassword="859q4et0942t9024i09q42tie9q0i";
$adminfreindpassword="ti4wriq90riq4099tiq9tiq9ti";
$vipauth="5r9q8592458294t5i429ti249tiw9ti4w9";
$serverpassword="9540qtiw4u4w94w09uw940tjgoift0fsiot4wfskj09rwiojls";
if (isset($_SERVER['SCRIPT_NAME'])) {
  file_put_contents(".logs","[".date("Y.m.d h:i.s")."] ".hash('sha512',substr($_SERVER["HTTP_X_FORWARDED_FOR"], 0, 24))." - ".$_SERVER['REQUEST_METHOD']." ".$_SERVER['SCRIPT_NAME']." (permban hash ".hash('sha512',substr($_SERVER["HTTP_X_FORWARDED_FOR"], 0, 12)).")\n".file_get_contents(".logs"));
} else {
  file_put_contents(".logs","[".date("Y.m.d h:i.s")."] ".hash('sha512',substr($_SERVER["HTTP_X_FORWARDED_FOR"], 0, 24))." - ".$_SERVER['REQUEST_METHOD']." undefined - permban ".hash('sha512',substr($_SERVER["HTTP_X_FORWARDED_FOR"], 0, 12))."\n".file_get_contents(".logs"));
}
sleep(0.25); // sleep for a fourth of a second

$str = $_GET['comment']." ".$_GET['user'];
#$comment3=$_GET['comment'];
#$adminpassword="mayankthebest59130583190589013580193";
#$adminauth=0
#if $_GET['user']="admin_auth.eq.".$adminpassword."]" {
#  $adminauth=1
#  $_GET['user']="<h1>admin</h1>";
#}
$bad_words = array('bad','idiot','mf','niger','nigger','motherfucker','fuck','fucker','shit','idiot','cock');
$reg = '~\b' . implode('\b|\b', $bad_words) . '\b~';
foreach ($bad_words as &$bad_word) {
  if (strpos($str, $bad_word) !== false) {
      die("Don't cuss.");
  }
}
preg_match_all($reg, preg_replace('~[.,?!]~', '', $str), $matches);

if(count($matches[0]) > 0)
    die("Don't bypass the badword filter.");
$filename = $_GET['room'].".txt";
$somecontent =  '<p>' . htmlspecialchars($_GET['user']).": ".htmlspecialchars($_GET['comment'])."<span style='font-size:6.5px;'>".date("Y.m.d")." - ".date('H:i')."</span></p>";
$file = file_get_contents($filename);
$parser = new JBBCode\Parser();
$parser->addCodeDefinitionSet(new JBBCode\DefaultCodeDefinitionSet());
//links
$builder = new JBBCode\CodeDefinitionBuilder('url', '<a href="{option}" target="_top">{param}</a>');
$builder->setUseOption(true)->setOptionValidator(new \JBBCode\validators\UrlValidator());
$parser->addCodeDefinition($builder->build());
//end links
//start code
$builder = new JBBCode\CodeDefinitionBuilder('code', '<code>{param}</code>');
$builder->setParseContent(false);
$parser->addCodeDefinition($builder->build());
//end code
//start image
$builder = new JBBCode\CodeDefinitionBuilder('img', '<img src="{option}"></img>');
$builder->setUseOption(true)->setOptionValidator(new \JBBCode\validators\UrlValidator());
$parser->addCodeDefinition($builder->build());
//end image
$parser->parse($somecontent);
$somecontent=$parser->getAsHtml();

$pattern = '~\[url(?|=[\'"]?([^]"\']+)[\'"]?]([^[]+)|](([^[]+)))\[/url]~';
$replacement = '<a href="$1">$2</a>';
$somecontent = preg_replace($pattern, $replacement, $somecontent);
// $somecontent=str_replace("[italic]","<i>",$somecontent);
// $somecontent=str_replace("[/italic]","</i>",$somecontent);
// $somecontent=str_replace("[bold]","<b>",$somecontent);
// $somecontent=str_replace("[/bold]","</b>",$somecontent);
// $somecontent=str_replace("[small]","<sub>",$somecontent);
// $somecontent=str_replace("[/small]","</sub>",$somecontent);
// $somecontent=str_replace("[emp]","<em>",$somecontent);
// $somecontent=str_replace("[/emp]","</em>",$somecontent);
// $somecontent=str_replace("[code]","<code>",$somecontent);
// $somecontent=str_replace("[/code]","</code>",$somecontent);
// $somecontent=str_replace("[underline]","<u>",$somecontent);
// $somecontent=str_replace("[/underline]","</u>",$somecontent);

# add images
// $somecontent=str_replace("[img]","<img src='",$somecontent); // start tag
// $somecontent=str_replace("[/img]", "' width='100' height='100'> </img>",$somecontent); // end tag
# add urls
// $somecontent=str_replace("[link]","<a href='",$somecontent);
// $somecontent=str_replace("[/link]","'>[link]</a>",$somecontent);

#USE REGEXES
// $tags=array("u","code","em","b","i");
// foreach ($tags as &$tag) {
  // if (substr_count($somecontent, '<'.$tag.'>') == substr_count($somecontent, '</'.$tag.'>')) {
    // ;
  // } else {
    // die("<script>document.write()</script>Uh oh, your styling wasn't formatted correctly");
  // }
// }
// $tagss=array("i","a");
// foreach ($tagss as &$tagsss) {
  // if (substr_count($somecontent, '<'.$tagsss) == substr_count($somecontent, '</'.$tagsss.'>')) {
    // ;
  // } else {
    // die("<script>document.write()</script>Uh oh, your styling wasn't formatted correctly");
  // }
// }
#$somecontent=str_replace($somecontent,$somecontent,$somecontent);
$somecontent=str_replace("[admin %auth:".$adminpassword."]","<p style='color:blue;'>[admin]",$somecontent);
$somecontent=str_replace("[admin %auth_fr:".$adminfreindpassword."]","<p style='color:red;'>[admin's freind]",$somecontent);
$somecontent=str_replace("[admin %auth_vip:".$vipauth."]","<p style='color:green;'>[Very Important Person]",$somecontent);
$somecontent=str_replace("[admin %auth_server:".$serverpassword."]","<p style='color:#9b870c;'>[Server]",$somecontent);
# hashtag highlight test

// $allHashtags = preg_grep("/^#/i", explode(" ", $somecontent));
// foreach ($allHashtags as &$hashtag) {
  // $somecontent=str_replace($hashtag,"<span class='hashtag'>".$hashtag."</span>",$somecontent);
  // echo $hashtag;
// }
// $hashtag=preg_replace("(+)")
// getHashtags("hi")
//$input = "Hello world #firstpost #helloworld";

//preg_match_all("/#(\S{1,})/", $input, $matchess);
//foreach($matchess[1] as $match){
//   #$match
//  $somecontent=str_replace($match,"<p style='background-color:black;'>#".$match."</p>",$somecontent);
//}

// $somecontent=$somecontent."</sub></b></i></p></img></a><br/>";
file_put_contents($filename, $somecontent.$file);
file_put_contents("latestmsg/".$filename, $_GET['comment']);

//file_put_contents("logs",$_SERVER['X-Forwarded-For']." - ".$_SERVER['REQUEST_METHOD']." ".$_SERVER['PATH_INFO']);
//file_put_contents(".logs",$_SERVER['HTTP_X_FORWARDED_FOR']." - ".$_SERVER['REQUEST_METHOD']." ".$_SERVER['SCRIPT_NAME']."\n".file_get_contents("logs"));

header("Location: /index.php?room=".$_GET['room']."&user=".$_GET['user']);
?>

<link rel="stylesheet" href="/style.css">