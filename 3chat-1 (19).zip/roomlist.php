<i>List of chats (ctrl + click)</i>
<hr/>
<!--hi!--><body>
<?php
//room list
//if (isset($_SERVER['SCRIPT_NAME'])) {
//  file_put_contents(".logs","[".date("Y.m.d h:i.s")."] ".hash('sha512',substr($_SERVER["HTTP_X_FORWARDED_FOR"], 0, 24))." - ".$_SERVER['REQUEST_METHOD']." ".$_SERVER['SCRIPT_NAME']." (permban hash ".hash('sha512',substr($_SERVER["HTTP_X_FORWARDED_FOR"], 0, 12)).")\n".file_get_contents(".logs"));
//} else {
//  file_put_contents(".logs","[".date("Y.m.d h:i.s")."] ".hash('sha512',substr($_SERVER["HTTP_X_FORWARDED_FOR"], 0, 24))." - ".$_SERVER['REQUEST_METHOD']." undefined - permban ".hash('sha512',substr($_SERVER["HTTP_X_FORWARDED_FOR"], 0, 12))."\n".file_get_contents(".logs"));
//}
function startsWith( $haystack, $needle ) {
     $length = strlen( $needle );
     return substr( $haystack, 0, $length ) === $needle;
}


$roomlist=explode("\n",shell_exec("ls -tr | sort -r | grep .txt"));
$x=0;
foreach ($roomlist as &$room) {
  $x++;
  if (strpos($room,".txt") !== false) {
    if ($room === "" or startsWith($room,"[hidden] ")) {
      ;
    }
    else {
      #echo $room;
      $room=str_replace(".txt","",$room);
      #echo $room;
      $room=htmlspecialchars($room);
      //<a href="/index.php?room="> </a>
      echo '<a href="/index.php?room='.$room.'" target="_top" style="color:white;background-color:grey;"><input value="'.$room.'" readonly> </a> <br/> ';

    }
  } else {
    ;
  }
}


?>


<link rel="stylesheet" href="/style.css">