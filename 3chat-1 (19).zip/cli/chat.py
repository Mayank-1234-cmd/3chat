def write(text):
  print("\033[0;35m%s\033[0m" % text)
def choice(text):
  print("\033[0;34m%s\033[0m" % text)
def prompt(text):
  return input("\033[0;32m%s:\033[0m" % text)
def raw_prompt(text):
  return raw_input("\033[0;32m%s:\033[0m" % text)
# im better in python
try:
  import urllib.request as urllib2
except ImportError as e:
  exit("Importing failed. Install urllib.")
  #import urllib.request as urllib2
  import os;___=os.system("pip install urllib3")
  import urllib.request as urllib2 # a free downgrade!
write("3chat-1 - @mkcodes")
server = prompt("Enter server")
server=server.replace("https://","")
server=server.replace("http://","")
server=server.replace("/","")
chatroom=prompt("Enter chatroom")
# /cli
# server+"/cli"
def cat(link):
  link="https://"+link
  link=link.replace(" ","%20")
  response = urllib2.urlopen(link)
  page_source = response.read()
  return page_source
while True:
  name=prompt("Name (leave empty if no post)")
  comment=prompt("Comment (leave empty if no post)")
  if name=="" and comment=="":
    print('\x1bc')
    write(str(cat(server+"/cli/"+chatroom+".chat")).replace("\\n","\n"))
    # cats r the best
    #the name came from linux cat [filename]
    write("Rooms\n___\n")
    write(str(cat(server+"/cli/list.php")))
    prompt("Press enter to continue..")
  else:
    cat(server+"/cli/post.php?name="+name+"&comment="+comment+"&chatroom="+chatroom)
    #print(cat(server+"/cli/"+chatroom+".chat"))
    print(chr(27)+'[2j')
    print('\033c')
    print('\x1bc')
    write(str(cat(server+"/cli/"+chatroom+".chat")).replace("\\n","\n"))
    write("Rooms\n___\n")
    write(str(cat(server+"/cli/list.php")))
    #