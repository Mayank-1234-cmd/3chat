#!/bin/bash
# cli

echo 'If chatroom does not exist, it automatically gets created.'
read -sp Chatroom: opt

