<?php
# curl gets source of this and then php writes it because it recieved a request in the first place
# create == first chat in file
file_put_contents($_GET['chatroom'].".chat",file_get_contents($_GET['chatroom'].".chat")."\n".$_GET['name'].": ".$_GET['comment']."[posted at: ".date("Y.m.d")." - ".date('H:i')."]");
