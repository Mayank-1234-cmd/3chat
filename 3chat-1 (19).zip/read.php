<?php
require_once "jbbcode/jBBCode/JBBCode/Parser.php";

$somecontent=$_GET['room'];
$parser = new JBBCode\Parser();
$parser->addCodeDefinitionSet(new JBBCode\DefaultCodeDefinitionSet());
//links
$builder = new JBBCode\CodeDefinitionBuilder('url', '<a href="{option}" target="_top">{param}</a>');
$builder->setUseOption(true)->setOptionValidator(new \JBBCode\validators\UrlValidator());
$parser->addCodeDefinition($builder->build());
//end links
//start code
$builder = new JBBCode\CodeDefinitionBuilder('code', '<code>{param}</code>');
$builder->setParseContent(false);
$parser->addCodeDefinition($builder->build());
//end code
//start image
$builder = new JBBCode\CodeDefinitionBuilder('img', '<img src="{option}"></img>');
$builder->setUseOption(true)->setOptionValidator(new \JBBCode\validators\UrlValidator());
$parser->addCodeDefinition($builder->build());
//end image
$parser->parse($somecontent);
$somecontent=$parser->getAsHtml();
?>
<!--hi!--><body>
 <i><?php echo htmlspecialchars($_GET['room']);?> (<a href=<?php echo '"/read.php?room=' . $_GET['room'] . '"';?> target="_top">Spectate</a>)</i><hr/><?php echo nl2br(shell_exec("cat " . escapeshellarg($_GET[
  'room'
]).".txt"));;

?><script src="https://twemoji.maxcdn.com/v/latest/twemoji.min.js" crossorigin="anonymous"></script><script> document.getElementsByTagName("body")[0].innerHTML=twemoji.parse(document.getElementsByTagName("body")[0].innerHTML) </script>



<link rel="stylesheet" href="/style.css">