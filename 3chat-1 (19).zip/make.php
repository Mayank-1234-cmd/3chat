<?php

sleep(1)