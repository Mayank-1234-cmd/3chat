<?php
function login($user,$pass,$passwordFile,$algo) {
  $cont=file_get_contents($passwordFile);
  $find=$user."=".hash($algo,$pass);
  if (str_contains($find,$cont)) {
    return true;
  }
  else {
    return false;
  }
}
function makeuser($user,$pass,$passwordFile,$algo) {
  file_put_contents($passwordFile,$user."=".hash($algo,$pass));
}
function loadCapatcha(){
  ;
}
