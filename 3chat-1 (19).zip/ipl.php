<?php
echo hash('sha512',substr($_SERVER["HTTP_X_FORWARDED_FOR"], 0, 24));
echo "<br/>";
echo substr($_SERVER["HTTP_X_FORWARDED_FOR"], 0, 24);
echo $_SERVER['HTTP_X_FORWARDED_FOR'];