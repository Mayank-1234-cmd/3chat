text-to-speech as a Base64 string
The following example demonstrates synchronous converting text-to-speech as a Base64 string and plays it in an internet browser:

<?php
$apiKey="cae6ce74ed4c4268a4a3a009b5eedd34";
$url="http://api.voicerss.org/?key=".$key."&hl=en-us&src=test";