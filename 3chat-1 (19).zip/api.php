<style>
* {
  opacity: 75%;
  color:white;
}
body { 
  background-image: url('https://malwarewatch.org/images/backgrounds/background<?php echo rand(1,20);?>.jpg');
}
@import url('https://fonts.googleapis.com/css2?family=Roboto+Mono:wght@100&display=swap');

code {
  font-family: 'Roboto Mono', monospace;
}
textarea {color:black;}
</style>
<h1> The API </h1><br/>
<p> Docs</p>

<code>/create.php?room=[room]</code>- make a room
<br/>
<code>/post.php?user=[user]&comment=[comment]&room=[roomname]</code>- post a comment
<br/>
<code>/latestmsg/[roomname].txt</code>- get latest message for [roomname]

PYTHON EXAMPLE!!<br/>
<textarea rows=25 cols=50>
import requests
def source(site):
  return requests.get("https://3chat-1.mkcodes.repl.co/"+site).text
def latestmsg(roomname):
  return source("latestmsg/%s.txt" % roomname)
def post(user,comment,room):
  return source('post.php?user=%s&comment=%s&room=%s' % (user,comment,room))
def createRoom(room):
  return source("/create.php?room=%s" % room)
import time
while True:
  if latestmsg('default')=="/help":
    post('CommenterBot [/]',"No commands are available yet!","default")
  else:
    pass
</textarea>