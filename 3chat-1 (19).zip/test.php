
<script>


function dsmt(txt) {
  let utter = new SpeechSynthesisUtterance();
  utter.lang = 'en-US';
  utter.text = txt;
  utter.volume = 0.5;
  utter.onend = function() {
    alert('Speech has finished');
  }
  window.speechSynthesis.speak(utter);
}
</script>
<button type="button" onclick="dsmt('hi')"> say hi </button>