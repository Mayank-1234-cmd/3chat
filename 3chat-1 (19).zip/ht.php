<?php
$somecontent="hi #hi hi #hi ";
$allHashtags = preg_grep("/^#/i", explode(" ", $somecontent));
foreach ($allHashtags as &$hashtag) {
  $somecontent=str_replace($hashtag,"<span class='hashtag'>".$hashtag."</span>",$somecontent);
}
echo $somecontent;